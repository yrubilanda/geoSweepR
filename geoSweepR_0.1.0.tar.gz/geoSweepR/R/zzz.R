utils::globalVariables(c(
  "grid_id", "geometry", "count", "area_km2", "density", "var1.pred",
  "x", "y", "level"
))
